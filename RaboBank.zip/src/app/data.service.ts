import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class DataService {
    tableDataSource: any;
    tableColumnsToDisplay: any;
    displayedColumns: any;
    constructor() { }
}