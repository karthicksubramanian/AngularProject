import { AfterViewChecked, AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-csv',
  templateUrl: './csv.component.html',
  styleUrls: ['./csv.component.css']
})
export class CsvComponent implements OnInit, AfterViewInit {
  file: any = 'Choose file';

  displayedColumns: string[] = [];
  columnsToDisplay: string[];
  data: any = new MatTableDataSource();
  tableShow = false;

  @ViewChild('csvReader') csvReader: any;
  

  constructor(
    private dataService: DataService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // this.data.paginator = this.paginator;
    // this.data.sort = this.sort;
  }

  ngAfterViewInit() {
    // this.data.paginator = this.paginator;
    // this.data.sort = this.sort;
    // console.log(this.data);
  }

  uploadListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;
    console.log(files);

    if (this.isValidCSVFile(files[0])) {

      this.file = files[0];

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);
        this.dataService.displayedColumns = headersRow;
        this.dataService.tableDataSource = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow);
        // this.dataService.tableColumnsToDisplay = this.displayedColumns.slice();
        // this.tableShow = true;
        console.log(this.data);

        this.router.navigate(['csv/resultview']);



      };

      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };

    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, header: any) {
    let csvArr = [];

    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == header.length) {
        let csvRecord = new Map;
        for (let j = 0; j < header.length; j++) {
          csvRecord.set(header[j].trim(), curruntRecord[j].trim());
        }
        let jsonObject = {};
        csvRecord.forEach(
          (v, k) => {
            jsonObject[k] = v;
          }
        );
        csvArr.push(jsonObject);
      }
    }
    return csvArr;
  }

  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.csvReader.nativeElement.value = "";
    this.data = [];
  }

}
